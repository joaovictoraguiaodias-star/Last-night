package com.lastnight.survival

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.Choreographer
import kotlin.math.*
import kotlin.random.Random

class LastNightView(context: Context) : View(context), Choreographer.FrameCallback {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD) }
    private var sw = 1f
    private var sh = 1f
    private var running = false
    private var lastNs = 0L
    private var t = 0f
    private var hp = 100f
    private var ammo = 30
    private var kills = 0
    private var wave = 1
    private var reload = 0f
    private var shotCooldown = 0f
    private var damageFlash = 0f
    private var hitFlash = 0f
    private var muzzle = 0f
    private var flashlight = true
    private var playerX = 10.5f
    private var playerY = 12.5f
    private var angle = -PI.toFloat() / 2f
    private var joystickX = 0f
    private var joystickY = 0f
    private var stickPointer = -1
    private var lookPointer = -1
    private var firePointer = -1
    private var lastLookX = 0f
    private var fireHeld = false
    private var walkPhase = 0f
    private var gameOver = false
    private var showHelp = true
    private var toast = ""
    private var toastTime = 0f
    private val fov = PI.toFloat() / 2.8f
    private val mapW = 24
    private val mapH = 24
    private val world = Array(mapH) { y -> IntArray(mapW) { x -> if (x == 0 || y == 0 || x == mapW - 1 || y == mapH - 1) 1 else 0 } }
    private val zeds = mutableListOf<Zombie>()
    private val particles = mutableListOf<Particle>()
    private val debris = mutableListOf<Debris>()
    private val depth = FloatArray(1000)
    private val wallColors = intArrayOf(Color.rgb(65, 72, 66), Color.rgb(77, 78, 67), Color.rgb(66, 62, 53), Color.rgb(49, 56, 51))
    private val red = Color.rgb(198, 48, 43)
    private val hud = Color.rgb(224, 232, 225)

    private data class Zombie(var x: Float, var y: Float, var hp: Int = 3, var speed: Float = .55f,
                              var attack: Float = .4f, var phase: Float = 0f, var flash: Float = 0f)
    private data class Particle(var x: Float, var y: Float, var z: Float, var vx: Float, var vy: Float,
                                var life: Float, var blood: Boolean)
    private data class Debris(val x: Float, val y: Float, val r: Float, val shade: Int)

    init {
        isFocusable = true
        setLayerType(View.LAYER_TYPE_HARDWARE, null)
        buildWorld()
        post { Choreographer.getInstance().postFrameCallback(this) }
    }

    private fun buildWorld() {
        for (y in 2 until mapH - 2) { world[y][4] = 1; world[y][19] = 1 }
        for (x in 2 until mapW - 2) { world[5][x] = 1; world[18][x] = 1 }
        for (x in 7..16) world[5][x] = 0
        listOf(Pair(4,3),Pair(4,10),Pair(4,15),Pair(19,8),Pair(19,13),Pair(6,18),Pair(16,18)).forEach { world[it.second][it.first] = 0 }
        repeat(45) {
            val x = Random.nextInt(2,22); val y = Random.nextInt(2,22)
            if (abs(x-playerX)>3 && abs(y-playerY)>3 && world[y][x] == 0) world[y][x] = if (Random.nextFloat() < .65f) 2 else 3
        }
        debris.clear()
        repeat(160) { debris.add(Debris(Random.nextFloat()*mapW, Random.nextFloat()*mapH, Random.nextFloat()*.08f+.015f, Random.nextInt(0,4))) }
    }

    private fun resetGame() {
        hp = 100f; ammo = 30; kills = 0; wave = 1; reload = 0f; shotCooldown = 0f; damageFlash = 0f
        playerX = 10.5f; playerY = 12.5f; angle = -PI.toFloat()/2f
        joystickX = 0f; joystickY = 0f; gameOver = false; showHelp = false
        zeds.clear(); particles.clear()
        repeat(7) { spawnZombie(true) }
        running = true
        toast = "OPERAÇÃO INICIADA"; toastTime = 1.2f
        lastNs = 0L
    }

    private fun cell(x: Float, y: Float): Int {
        val ix = floor(x).toInt(); val iy = floor(y).toInt()
        if (ix !in 0 until mapW || iy !in 0 until mapH) return 1
        return world[iy][ix]
    }
    private fun wall(x: Float, y: Float) = cell(x,y) > 0
    private fun canMove(x: Float, y: Float): Boolean =
        !wall(x-.18f,y-.18f) && !wall(x+.18f,y-.18f) && !wall(x-.18f,y+.18f) && !wall(x+.18f,y+.18f)

    private fun spawnZombie(front: Boolean = false) {
        var x = playerX; var y = playerY
        var found = false
        for (attempt in 0 until 30) {
            val a = angle + Random.nextFloat() * (if(front) 1.05f else 1.7f) - (if(front) .525f else .85f)
            val d = if(front) 4f + Random.nextFloat()*2.5f else 6f + Random.nextFloat()*8f
            x = playerX + cos(a)*d; y = playerY + sin(a)*d
            if (canMove(x,y) && hypot(x-playerX,y-playerY) > 2.8f) { found = true; break }
        }
        if (!found) {
            x = 8f + Random.nextFloat()*8f; y = 4f + Random.nextFloat()*4f
        }
        zeds.add(Zombie(x,y,2 + wave/3,.48f + Random.nextFloat()*.22f + wave*.025f,Random.nextFloat(),Random.nextFloat()*6.28f))
    }

    override fun doFrame(frameTimeNanos: Long) {
        Choreographer.getInstance().postFrameCallback(this)
        val dt = if (lastNs == 0L) 1f/60f else ((frameTimeNanos-lastNs)/1e9).toFloat().coerceIn(0f,.035f)
        lastNs = frameTimeNanos
        if (running) update(dt)
        invalidate()
    }

    private fun update(dt: Float) {
        t += dt; shotCooldown = max(0f,shotCooldown-dt); muzzle = max(0f,muzzle-dt); damageFlash=max(0f,damageFlash-dt)
        hitFlash=max(0f,hitFlash-dt); reload=max(0f,reload-dt)
        if (reload == 0f && ammo == 0) { ammo = 30; toast = "CARREGADOR TROCADO"; toastTime = 1f }
        if (toastTime > 0f) toastTime -= dt
        if (fireHeld && shotCooldown <= 0f) shoot()
        val forward = -joystickY
        val strafe = joystickX
        val speed = 2.6f*dt
        val nx = playerX + cos(angle)*forward*speed + cos(angle+PI.toFloat()/2)*strafe*speed
        val ny = playerY + sin(angle)*forward*speed + sin(angle+PI.toFloat()/2)*strafe*speed
        if (canMove(nx,playerY)) playerX=nx
        if (canMove(playerX,ny)) playerY=ny
        if (abs(forward)+abs(strafe)>.1f) walkPhase += dt*10f
        for (z in zeds) {
            val dx=playerX-z.x; val dy=playerY-z.y; val d=hypot(dx,dy).coerceAtLeast(.001f)
            if (d>.62f) {
                val vx=dx/d*z.speed*dt; val vy=dy/d*z.speed*dt
                if(canMove(z.x+vx,z.y))z.x+=vx
                if(canMove(z.x,z.y+vy))z.y+=vy
            } else if(z.attack<=0f) {
                hp-=8.5f; damageFlash=.45f; z.attack=.85f
                if(hp<=0f){hp=0f;running=false;gameOver=true;toast="MISSÃO FALHOU"}
            }
            z.attack=max(0f,z.attack-dt);z.phase+=dt*5f;z.flash=max(0f,z.flash-dt)
        }
        if (zeds.size < min(24,5+wave*2) && Random.nextFloat() < dt*.24f) spawnZombie()
        val it=particles.iterator()
        while(it.hasNext()){val b=it.next();b.life-=dt;b.x+=b.vx*dt;b.y+=b.vy*dt;b.z+=b.vx*dt*.12f;if(b.life<=0)it.remove()}
    }

    private fun shoot() {
        if (!running || reload>0f || ammo<=0 || shotCooldown>0f) return
        ammo--; shotCooldown=.16f; muzzle=.09f
        var target: Zombie?=null; var best=1000f
        for(z in zeds) {
            val dx=z.x-playerX; val dy=z.y-playerY; val d=hypot(dx,dy)
            if(d>13f)continue
            val diff=wrap(atan2(dy,dx)-angle)
            val score=abs(diff)*d
            if(abs(diff)<.105f && score<best && lineClear(playerX,playerY,z.x,z.y)){target=z;best=score}
        }
        if(target!=null) {
            val z=target!!; z.hp--;z.flash=.12f;hitFlash=.12f;burst(z.x,z.y,9)
            if(z.hp<=0) {
                burst(z.x,z.y,20);zeds.remove(z);kills++
                if(kills%7==0){wave++;repeat(min(2+wave,7)){spawnZombie()}}
                toast="ALVO ELIMINADO";toastTime=.9f
            }
        } else { toast="DISPARO";toastTime=.35f }
        invalidate()
    }
    private fun wrap(a: Float): Float { var x=a; while(x>PI)x-=2*PI.toFloat();while(x< -PI)x+=2*PI.toFloat();return x }
    private fun lineClear(x1:Float,y1:Float,x2:Float,y2:Float):Boolean {
        val d=hypot(x2-x1,y2-y1);val n=(d/.08f).toInt().coerceAtLeast(1)
        for(i in 1 until n){val k=i.toFloat()/n;if(wall(x1+(x2-x1)*k,y1+(y2-y1)*k))return false}
        return true
    }
    private fun burst(x:Float,y:Float,n:Int) { repeat(n){particles.add(Particle(x,y,Random.nextFloat(),Random.nextFloat()*2-1,Random.nextFloat()*2-1,.25f+Random.nextFloat()*.5f,true))} }
    private fun reloadGun(){if(reload<=0f && ammo<30){reload=1.15f;fireHeld=false;toast="RECARREGANDO";toastTime=1f}}
    private fun toggleFlash(){flashlight=!flashlight;toast=if(flashlight)"LANTERNA LIGADA" else "LANTERNA DESLIGADA";toastTime=.7f}

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        sw=width.toFloat().coerceAtLeast(1f); sh=height.toFloat().coerceAtLeast(1f)
        c.drawColor(Color.rgb(9,13,13))
        if (!running && !gameOver) { drawMenu(c); return }
        drawWorld(c)
        drawWeapon(c)
        drawHud(c)
        if(gameOver)drawGameOver(c)
    }

    private fun drawWorld(c:Canvas) {
        val horizon=sh*.47f+sin(walkPhase)*1.5f
        p.shader=LinearGradient(0f,0f,0f,horizon,Color.rgb(14,22,25),Color.rgb(67,69,57),Shader.TileMode.CLAMP);c.drawRect(0f,0f,sw,horizon,p);p.shader=null
        p.shader=LinearGradient(0f,horizon,0f,sh,Color.rgb(51,57,49),Color.rgb(8,11,10),Shader.TileMode.CLAMP);c.drawRect(0f,horizon,sw,sh,p);p.shader=null
        val cols=min(720,max(180,(sw/2.1f).toInt()));val colW=sw/cols
        if(depth.size<cols) { /* fixed array is enough for typical phone widths */ }
        for(i in 0 until cols) {
            val cam=(i.toFloat()/cols-.5f)*fov
            val ray=cast(angle+cam);val dist=max(.12f,ray.first*cos(cam))
            val wallH=min(sh*1.65f,sh*1.05f/dist);val top=horizon-wallH/2
            val base=wallColors[(ray.second.coerceIn(1,3)-1)%wallColors.size]
            var shade=(1f-dist/17f).coerceIn(.12f,1f)*(if(ray.third).76f else 1f)
            if(flashlight) {
                val beam=(1f-abs(cam)/.56f).coerceIn(0f,1f)*(1f-dist/11f).coerceIn(0f,1f)
                shade=(shade+beam*.42f).coerceAtMost(1f)
            } else shade*=.55f
            p.color=Color.rgb((Color.red(base)*shade).toInt(),(Color.green(base)*shade).toInt(),(Color.blue(base)*shade).toInt())
            c.drawRect(i*colW,top,i*colW+colW+1,top+wallH,p)
            if(wallH>20 && i%7==0){p.color=Color.argb(35,0,0,0);c.drawRect(i*colW,top+wallH*.32f,i*colW+colW+1,top+wallH*.34f,p);c.drawRect(i*colW,top+wallH*.68f,i*colW+colW+1,top+wallH*.70f,p)}
        }
        // Debris projected into the lower half of the corridor.
        for(d in debris) {
            val dx=d.x-playerX;val dy=d.y-playerY;val dist=hypot(dx,dy)
            if(dist<.6f||dist>10f)continue
            val diff=wrap(atan2(dy,dx)-angle);if(abs(diff)>fov*.7f)continue
            val sx=sw/2+tan(diff)/tan(fov/2)*(sw/2);val sy=horizon+sh*.65f/dist
            val size=(sw*.012f/dist).coerceIn(1f,7f)
            p.color=intArrayOf(Color.rgb(92,91,76),Color.rgb(39,45,40),Color.rgb(104,95,77),Color.rgb(27,33,30))[d.shade]
            c.drawRect(sx,sy,sx+size,sy+size*.45f,p)
        }
        val sorted=zeds.sortedByDescending{hypot(it.x-playerX,it.y-playerY)}
        for(z in sorted) drawZombie(c,z,horizon)
        // flashlight cone and edge vignette
        if(flashlight) {
            p.shader=RadialGradient(sw*.5f,sh*.53f,min(sw,sh)*.08f,intArrayOf(Color.argb(30,255,239,190),Color.argb(0,255,239,190)),null,Shader.TileMode.CLAMP)
            c.drawRect(0f,0f,sw,sh,p);p.shader=null
        }
        p.shader=RadialGradient(sw*.5f,sh*.5f,min(sw,sh)*.28f,intArrayOf(Color.TRANSPARENT,Color.argb(165,0,0,0)),null,Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,sw,sh,p);p.shader=null
    }

    // Grid DDA raycaster: much faster than tiny fixed steps, especially on 120 Hz phones.
    private fun cast(a:Float):Triple<Float,Int,Boolean>{
        val dx=cos(a); val dy=sin(a)
        var mx=floor(playerX).toInt(); var my=floor(playerY).toInt()
        val deltaX=if(abs(dx)<0.00001f) 1.0e8f else abs(1f/dx)
        val deltaY=if(abs(dy)<0.00001f) 1.0e8f else abs(1f/dy)
        val stepX=if(dx<0f)-1 else 1
        val stepY=if(dy<0f)-1 else 1
        var sideX=if(dx<0f)(playerX-mx)*deltaX else (mx+1f-playerX)*deltaX
        var sideY=if(dy<0f)(playerY-my)*deltaY else (my+1f-playerY)*deltaY
        var side=false
        for(i in 0 until 80){
            val dist:Float
            if(sideX<sideY){sideX+=deltaX;mx+=stepX;dist=sideX-deltaX;side=false}
            else{sideY+=deltaY;my+=stepY;dist=sideY-deltaY;side=true}
            if(mx !in 0 until mapW || my !in 0 until mapH)return Triple(dist.coerceAtLeast(.1f),1,side)
            val hit=world[my][mx]
            if(hit>0)return Triple(dist.coerceAtLeast(.1f),hit,side)
        }
        return Triple(22f,1,false)
    }

    private fun drawZombie(c:Canvas,z:Zombie,horizon:Float) {
        val dx=z.x-playerX;val dy=z.y-playerY;val d=hypot(dx,dy);if(d<.2f||d>18f)return
        val diff=wrap(atan2(dy,dx)-angle);if(abs(diff)>fov*.75f)return
        val sx=sw/2+tan(diff)/tan(fov/2)*(sw/2)
        val col=((sx/sw)*min(720,max(180,(sw/2.1f).toInt()))).toInt().coerceIn(0,depth.lastIndex)
        if(d>depth[col]+.4f)return
        val scale=sh*.72f/d;val zw=scale*.36f;val zh=scale*1.12f;val baseY=horizon+scale*.28f
        val sway=sin(z.phase)*scale*.025f
        c.save();c.translate(sx+sway,baseY)
        val lit=if(flashlight)(1f-d/10f).coerceIn(.12f,1f) else (1f-d/17f).coerceIn(.1f,.5f)
        val coat=if(z.flash>0)Color.rgb(154,49,40) else if(lit>.55f)Color.rgb(48,57,49) else Color.rgb(19,25,23)
        p.color=coat
        c.drawRect(-zw*.47f,-zh*.34f,-zw*.13f,0f,p);c.drawRect(zw*.12f,-zh*.34f,zw*.46f,0f,p)
        val body=Path().apply{moveTo(-zw*.48f,-zh*.82f);lineTo(zw*.38f,-zh*.80f);lineTo(zw*.50f,-zh*.32f);lineTo(-zw*.42f,-zh*.30f);close()}
        c.drawPath(body,p)
        p.color=if(lit>.55f)Color.rgb(83,91,75) else Color.rgb(39,44,38)
        p.strokeWidth=max(1f,zw*.17f);p.strokeCap=Paint.Cap.ROUND
        c.drawLine(-zw*.35f,-zh*.75f,-zw*.64f,-zh*.43f+sin(z.phase)*zw*.16f,p)
        c.drawLine(zw*.35f,-zh*.74f,zw*.60f,-zh*.45f,p)
        p.color=Color.rgb(83,91,77);c.drawOval(-zw*.27f,-zh*1.03f,zw*.27f,-zh*.78f,p)
        p.color=Color.rgb(206,47,39);c.drawRect(-zw*.17f,-zh*.92f,-zw*.07f,-zh*.90f,p);c.drawRect(zw*.06f,-zh*.92f,zw*.16f,-zh*.90f,p)
        if(d<7f){p.color=Color.argb(190,195,205,194);c.drawRect(-zw*.4f,-zh*1.1f,zw*.4f,-zh*1.1f+2f,p);p.color=red;c.drawRect(-zw*.4f,-zh*1.1f,(-zw*.4f)+zw*.8f*(z.hp/3f).coerceIn(0f,1f),-zh*1.1f+2f,p)}
        c.restore()
    }

    private fun drawWeapon(c:Canvas) {
        val bob=sin(walkPhase*2)*min(5f,abs(joystickX)+abs(joystickY)*3)
        val recoil=if(muzzle>0f)9f else 0f
        c.save();c.translate(sw*.72f+bob,sh+20f)
        val gw=min(sw*.28f,170f);val gh=min(sh*.29f,190f)
        p.color=Color.rgb(36,42,38)
        val arm=Path().apply{moveTo(-gw*.5f,0f);lineTo(-gw*.25f,-gh*.4f);lineTo(gw*.02f,-gh*.4f);lineTo(gw*.18f,0f);close()};c.drawPath(arm,p)
        p.color=Color.rgb(99,96,81);c.drawOval(-gw*.28f,-gh*.37f,-gw*.01f,-gh*.17f,p)
        p.color=Color.rgb(14,18,17);c.drawRoundRect(gw*.00f,-gh*.73f-recoil,gw*.34f,5f,5f,5f,p)
        p.color=Color.rgb(52,60,54);c.drawRect(gw*.035f,-gh*.82f-recoil,gw*.26f,-gh*.48f,p)
        p.color=Color.rgb(7,10,9);c.drawRect(gw*.105f,-gh*.98f-recoil,gw*.17f,-gh*.75f-recoil,p)
        p.color=Color.rgb(76,83,73);c.drawRect(gw*.13f,-gh*.97f-recoil,gw*.145f,-gh*.78f-recoil,p)
        p.color=Color.rgb(18,22,20);c.drawRect(gw*.02f,-gh*.42f,gw*.20f,-gh*.18f,p)
        if(muzzle>0f){p.shader=RadialGradient(gw*.15f,-gh*.98f-recoil,gw*.16f,intArrayOf(Color.rgb(255,244,185),Color.argb(0,255,111,24)),null,Shader.TileMode.CLAMP);c.drawCircle(gw*.15f,-gh*.98f-recoil,gw*.17f,p);p.shader=null}
        c.restore()
    }

    private fun drawHud(c:Canvas) {
        val pad=16f
        p.color=Color.argb(220,6,10,10);c.drawRoundRect(pad,pad,pad+205,117f,5f,5f,p)
        p.color=red;c.drawRect(pad,pad,pad+3,117f,p)
        text.color=hud;text.textSize=19f;text.letterSpacing=.12f;c.drawText("LAST NIGHT",pad+12,37f,text)
        text.color=red;c.drawText("//",pad+126,37f,text)
        text.color=Color.rgb(173,187,177);text.textSize=9f;text.letterSpacing=.08f;c.drawText("OPERAÇÃO NOITE FRIA · SETOR 07",pad+12,52f,text)
        text.color=Color.rgb(176,188,179);text.textSize=9f;c.drawText("INTEGRIDADE DO OPERADOR",pad+12,69f,text)
        p.color=Color.rgb(36,43,39);c.drawRect(pad+12,76f,pad+156,84f,p)
        p.color=if(hp<30)Color.rgb(225,50,42)else Color.rgb(176,49,43);c.drawRect(pad+13,77f,pad+13+142f*(hp/100f).coerceIn(0f,1f),83f,p)
        text.color=hud;text.textSize=11f;c.drawText("${hp.toInt()}%",pad+164,84f,text)
        text.color=Color.rgb(215,223,216);text.textSize=10f;c.drawText("KILLS ${kills.toString().padStart(3,'0')}   AMEAÇAS ${zeds.size.toString().padStart(2,'0')}   ONDA ${wave.toString().padStart(2,'0')}",pad+12,103f,text)
        // top-center objective
        p.color=Color.argb(185,8,13,12);c.drawRect(sw*.5f-105,15f,sw*.5f+105,38f,p)
        p.color=Color.rgb(114,130,119);c.drawRect(sw*.5f-105,37f,sw*.5f+105,38f,p)
        text.color=hud;text.textSize=10f;text.textAlign=Paint.Align.CENTER;c.drawText("OBJETIVO: SOBREVIVA À ONDA",sw*.5f,30f,text);text.textAlign=Paint.Align.LEFT
        // center reticle
        p.color=if(hitFlash>0)Color.rgb(255,236,212)else Color.argb(230,229,237,228)
        val cx=sw*.5f;val cy=sh*.5f
        c.drawRect(cx-1,cy-11,cx+1,cy-4,p);c.drawRect(cx-1,cy+4,cx+1,cy+11,p);c.drawRect(cx-11,cy-1,cx-4,cy+1,p);c.drawRect(cx+4,cy-1,cx+11,cy+1,p)
        // ammo panel
        p.color=Color.argb(225,7,11,10);c.drawRoundRect(sw-151,sh-82,sw-13,sh-13,4f,4f,p);p.color=red;c.drawRect(sw-16,sh-82,sw-13,sh-13,p)
        text.color=Color.rgb(176,188,179);text.textSize=9f;c.drawText("FUZIL · 5.56 MM",sw-139,sh-65,text)
        text.color=hud;text.textSize=26f;c.drawText(ammo.toString().padStart(2,'0'),sw-139,sh-35,text)
        text.color=Color.rgb(151,163,153);text.textSize=12f;c.drawText("/ ∞",sw-100,sh-36,text)
        text.color=Color.rgb(157,171,160);text.textSize=8f;c.drawText(if(reload>0f)"RECARREGANDO..." else "SEMI / AUTOMÁTICO",sw-139,sh-21,text)
        // joystick
        val jx=68f;val jy=sh-70f
        p.color=Color.argb(85,12,18,16);p.style=Paint.Style.FILL;c.drawCircle(jx,jy,48f,p)
        p.color=Color.argb(110,188,202,190);p.style=Paint.Style.STROKE;p.strokeWidth=1.5f;c.drawCircle(jx,jy,48f,p)
        p.style=Paint.Style.FILL;p.color=Color.argb(100,195,209,198);c.drawCircle(jx+joystickX*27,jy-joystickY*27,18f,p)
        // controls and flashlight/reload labels
        drawButton(c,sw-74f,66f,60f,36f,if(flashlight)"LANTERNA ON" else "LANTERNA OFF",flashlight)
        drawButton(c,sw-78f,sh-132f,64f,34f,if(reload>0f)"..." else "RECARREGAR",false)
        drawButton(c,sw-78f,sh-54f,64f,64f,"ATIRAR",true)
        text.color=Color.rgb(174,187,177);text.textSize=9f;text.textAlign=Paint.Align.LEFT;c.drawText("ARRASTE PARA MIRAR",sw*.5f-64,sh-15,text)
        if(toastTime>0f){p.color=Color.argb(210,9,14,13);c.drawRoundRect(sw*.5f-95,sh*.22f,sw*.5f+95,sh*.22f+30,4f,4f,p);text.color=hud;text.textSize=11f;text.textAlign=Paint.Align.CENTER;c.drawText(toast,sw*.5f,sh*.22f+19,text);text.textAlign=Paint.Align.LEFT}
        if(damageFlash>0f){p.color=Color.argb((damageFlash*115).toInt().coerceIn(0,100),180,8,8);c.drawRect(0f,0f,sw,sh,p)}
    }
    private fun drawButton(c:Canvas,x:Float,y:Float,w:Float,h:Float,label:String,on:Boolean){
        p.color=if(on)Color.argb(210,73,57,37)else Color.argb(210,18,25,22);c.drawRoundRect(x,y,x+w,y+h,5f,5f,p)
        p.color=if(on)Color.rgb(216,190,126)else Color.rgb(106,123,112);p.style=Paint.Style.STROKE;p.strokeWidth=1f;c.drawRoundRect(x,y,x+w,y+h,5f,5f,p);p.style=Paint.Style.FILL
        text.color=if(on)Color.rgb(255,235,182)else hud;text.textSize=8f;text.textAlign=Paint.Align.CENTER;c.drawText(label,x+w/2,y+h/2+3f,text);text.textAlign=Paint.Align.LEFT
    }
    private fun drawMenu(c:Canvas){
        p.shader=LinearGradient(0f,0f,sw,sh,Color.rgb(13,22,24),Color.rgb(4,7,7),Shader.TileMode.CLAMP);c.drawRect(0f,0f,sw,sh,p);p.shader=null
        // abstract ruined skyline
        for(i in 0..13){val x=i*sw/13f;val bw=sw/18f;val bh=sh*(.16f+((i*37)%7)*.045f);p.color=Color.rgb(20+i%3*3,28+i%4*2,27+i%2*3);c.drawRect(x,sh*.58f-bh,x+bw,sh*.58f,p);for(w in 0..2){p.color=Color.argb(40,201,191,140);c.drawRect(x+5+w*8,sh*.58f-bh+12,x+9+w*8,sh*.58f-bh+19,p)}}
        p.color=Color.argb(185,4,8,8);c.drawRect(0f,0f,sw,sh,p)
        text.color=Color.rgb(166,180,169);text.textSize=12f;text.letterSpacing=.22f;text.textAlign=Paint.Align.CENTER;c.drawText("SINGLE PLAYER  ·  SURVIVAL PROTOCOL",sw/2,sh*.27f,text)
        text.color=hud;text.textSize=min(54f,sw*.075f);text.letterSpacing=.04f;c.drawText("LAST NIGHT",sw/2,sh*.40f,text)
        text.color=red;text.textSize=min(58f,sw*.08f);c.drawText("SURVIVAL",sw/2,sh*.49f,text)
        text.color=Color.rgb(175,188,178);text.textSize=12f;text.letterSpacing=.06f;c.drawText("CIDADE SEM ENERGIA · SOBREVIVA À HORDA",sw/2,sh*.57f,text)
        val bx=sw*.5f-125;val by=sh*.68f
        p.color=Color.rgb(171,44,38);c.drawRoundRect(bx,by,bx+250,by+54,5f,5f,p)
        text.color=Color.WHITE;text.textSize=17f;text.letterSpacing=.12f;c.drawText(if(gameOver)"TENTAR NOVAMENTE" else "INICIAR MISSÃO",sw/2,by+33,text)
        text.color=Color.rgb(126,143,132);text.textSize=10f;text.letterSpacing=0f;c.drawText("TOQUE NO BOTÃO PARA COMEÇAR",sw/2,sh*.84f,text)
        text.textAlign=Paint.Align.LEFT
    }
    private fun drawGameOver(c:Canvas){
        p.color=Color.argb(205,0,0,0);c.drawRect(0f,0f,sw,sh,p)
        text.textAlign=Paint.Align.CENTER;text.color=red;text.textSize=38f;c.drawText("MISSÃO FALHOU",sw/2,sh*.4f,text)
        text.color=hud;text.textSize=16f;c.drawText("ELIMINAÇÕES: $kills  ·  ONDA: $wave",sw/2,sh*.49f,text)
        p.color=Color.rgb(159,41,35);c.drawRoundRect(sw/2-125,sh*.58f,sw/2+125,sh*.58f+54,5f,5f,p)
        text.color=Color.WHITE;text.textSize=17f;c.drawText("TENTAR NOVAMENTE",sw/2,sh*.58f+33,text)
        text.textAlign=Paint.Align.LEFT
    }

    override fun onTouchEvent(e:MotionEvent):Boolean{
        val x=e.x;val y=e.y
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN,MotionEvent.ACTION_POINTER_DOWN -> {
                val idx=e.actionIndex;val px=e.getX(idx);val py=e.getY(idx);val id=e.getPointerId(idx)
                if(!running){
                    if(px in (sw*.5f-160)..(sw*.5f+160) && py in (sh*.62f)..(sh*.82f)){resetGame();invalidate();return true}
                    if(gameOver){resetGame();invalidate();return true}
                    return true
                }
                if(px<sw*.26f && py>sh*.57f){stickPointer=id;updateJoystick(px,py);return true}
                if(px>sw*.82f && py>sh*.73f){firePointer=id;fireHeld=true;shoot();return true}
                if(px>sw*.82f && py<sh*.28f){toggleFlash();invalidate();return true}
                if(px>sw*.80f && py>sh*.54f){reloadGun();invalidate();return true}
                lookPointer=id;lastLookX=px;return true
            }
            MotionEvent.ACTION_MOVE -> {
                for(i in 0 until e.pointerCount){
                    val id=e.getPointerId(i);val px=e.getX(i);val py=e.getY(i)
                    if(id==stickPointer)updateJoystick(px,py)
                    if(id==lookPointer && running){val dx=px-lastLookX;angle+=dx*.008f;lastLookX=px}
                }
                return true
            }
            MotionEvent.ACTION_UP,MotionEvent.ACTION_POINTER_UP,MotionEvent.ACTION_CANCEL -> {
                val idx=e.actionIndex;val id=e.getPointerId(idx)
                if(id==stickPointer){stickPointer=-1;joystickX=0f;joystickY=0f}
                if(id==firePointer){firePointer=-1;fireHeld=false}
                if(id==lookPointer)lookPointer=-1
                invalidate();return true
            }
        }
        return true
    }
    private fun updateJoystick(x:Float,y:Float){
        val cx=68f;val cy=sh-70f;val dx=x-cx;val dy=y-cy;val d=hypot(dx,dy).coerceAtLeast(1f);val m=min(1f,d/42f)
        joystickX=(dx/d*m).coerceIn(-1f,1f);joystickY=(-dy/d*m).coerceIn(-1f,1f)
    }
}

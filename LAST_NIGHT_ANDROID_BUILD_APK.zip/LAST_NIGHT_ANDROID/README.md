# LAST NIGHT — Android nativo

Este é um projeto Android nativo em Kotlin, sem WebView, sem emulador e sem bibliotecas de jogo externas. O jogo é desenhado diretamente numa View Android; controles de toque, botão de iniciar, joystick, mira, lanterna, tiro e recarga são tratados pelo app.

## Importante
- O pacote é o **projeto-fonte Android**, não um APK já compilado.
- Para gerar o APK é necessário Android Studio + Android SDK (API 35) e JDK 17.
- O projeto usa Gradle e baixa os plugins Android/Kotlin na primeira compilação.
- O jogo é um shooter de perspectiva raycasting/2.5D, não um motor 3D completo. O objetivo foi priorizar um app nativo offline e controles confiáveis.
- O app solicita landscape e prefere 120 Hz quando o aparelho oferece suporte; FPS real depende do sistema, tela e carga do aparelho.

## Gerar APK
1. Descompacte `LAST_NIGHT_ANDROID.zip`.
2. Abra a pasta `LAST_NIGHT_ANDROID` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use **Build > Build APK(s)**.
5. O APK debug normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Controles
- Joystick inferior esquerdo: mover.
- Arrastar a parte central da tela: mirar.
- Botão ATIRAR: disparar (segurar para automático).
- LANTERNA: ligar/desligar.
- RECARREGAR: recarregar.
